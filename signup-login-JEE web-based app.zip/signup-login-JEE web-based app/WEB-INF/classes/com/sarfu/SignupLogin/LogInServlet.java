package com.sarfu.SignupLogin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/LogInServlet")
public class LogInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PrintWriter pw =null;
	Connection conn =null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	
	private static final String LOGIN_QUERY="SELECT * FROM SIGNUP_TABLE WHERE username=? AND password=?";
	  public void init() {
	    	
	    	try {
	    	
	    		Class.forName("oracle.jdbc.driver.OracleDriver");
	    		conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","system","Sarfaraz123");
	    		if(conn!=null) {
	    			ps=conn.prepareStatement(LOGIN_QUERY);
	    			
	    		}else {	
	    			System.out.println("connection failed sarfaraz");
	    		}
	    	}catch(ClassNotFoundException cnfe) {
	    		
	    		cnfe.printStackTrace();
	    	}catch(SQLException sqle) {
	    		sqle.printStackTrace();
	    		
	    	}
	    	
	    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		pw= response.getWriter();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		try {
			ps.setString(1,username);
			ps.setString(2,password);
//			System.out.println(username);
//			System.out.println(password);
//				System.out.println("login_btn clicked");
//				System.out.println(rs);
				rs=ps.executeQuery();
//				System.out.println(rs);
				boolean login_sucess_failed_status =rs.next();
					if(login_sucess_failed_status==true) {
//						System.out.println("true block");
						ArrayList<String> resultSetArray = new ArrayList<String>(); 
						
						resultSetArray.add(rs.getString(1));
						resultSetArray.add(rs.getString(2));
						resultSetArray.add(rs.getString(3));
						resultSetArray.add(rs.getString(4));
						resultSetArray.add(rs.getString(5));
						resultSetArray.add(rs.getString(6));
						resultSetArray.add(rs.getString(7));
						resultSetArray.add(rs.getString(8));
						
						request.setAttribute("resultsetdata",resultSetArray);
						HttpSession session = request.getSession();
						session.setAttribute("username",rs.getString(5));
						
						 request.getRequestDispatcher("loginsucesspage.jsp").forward(request,response);
//						response.sendRedirect("loginsucesspage.jsp?resultsetdata"+resultSetArray);
					}else {
//						System.out.println("false block");
						String login_error_msg = "Sorry UserName or Password InCorrect!";  
				        request.setAttribute("login_error_msg", login_error_msg); 
						 RequestDispatcher rd=request.getRequestDispatcher("/LogInForm.jsp");
						 rd.forward(request,response);  
					}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
public void destroy() { 
		
		if (ps!=null && conn!=null) {
			try {
				ps.close(); 
				conn.close(); 
			} catch (SQLException e) { 
				e.printStackTrace();
			} 
		} 
	}

}
