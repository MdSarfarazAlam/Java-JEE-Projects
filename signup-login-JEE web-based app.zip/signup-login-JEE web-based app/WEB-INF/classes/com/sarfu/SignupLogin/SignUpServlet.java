package com.sarfu.SignupLogin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SignUpServlet")
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    Connection conn =null;
    PreparedStatement ps=null;
    PrintWriter pw=null;
    private static final String SIGNUP_INSERT_QUERY="INSERT INTO SIGNUP_TABLE VALUES(?,?,?,?,?,?,?,?)";
    public void init() {
    	
    	try {
    		System.out.println("connection init sarfaraz");
    		Class.forName("oracle.jdbc.driver.OracleDriver");
    		conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","system","Sarfaraz123");
    		if(conn!=null) {
    			ps=conn.prepareStatement(SIGNUP_INSERT_QUERY);
    		}else {	
    			System.out.println("connection failed");
    		}
    	}catch(ClassNotFoundException cnfe) {
    	
    		cnfe.printStackTrace();
    	}catch(SQLException sqle) {
    		sqle.printStackTrace();
    	
    	}
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		pw=response.getWriter();
		String fname= request.getParameter("fname");
		String lname= request.getParameter("lname");
		String email= request.getParameter("email");
		String phone= request.getParameter("phone");
		String username= request.getParameter("username");
		String password= request.getParameter("password");
		String birthdate= request.getParameter("birthdate");
		String gender= request.getParameter("gender");
		String signup_btn = request.getParameter("signup");
		try {
			ps.setString(1, fname);
			ps.setString(2, lname);
			ps.setString(3, email);
			ps.setString(4, phone);
			ps.setString(5, username);
			ps.setString(6, password);
			ps.setString(7, birthdate);
			ps.setString(8, gender);
			if(signup_btn.equals("signup_submit")) {
				int res=ps.executeUpdate();
				
				if(res==0) {
				
					response.sendRedirect("Signup_failed_page.html");
				}else {
					System.out.println("1");
					response.sendRedirect("Signup_success_page.html");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}
	public void destroy() { 
		
		if (ps!=null && conn!=null) {
			try {
				ps.close(); 
				conn.close(); 
			} catch (SQLException e) { 
				e.printStackTrace();
			} 
		} 
	}

}
