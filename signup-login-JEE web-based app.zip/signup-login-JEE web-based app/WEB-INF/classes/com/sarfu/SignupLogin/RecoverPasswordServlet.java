package com.sarfu.SignupLogin;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;


@WebServlet("/RecoverPasswordServlet")
public class RecoverPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String RECOVER_PASS_QUERY="SELECT email,username,phone FROM SIGNUP_TABLE WHERE email=? AND phone=?";
	PrintWriter pw =null;
	Connection conn =null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	private static final String OTP_APIKEY="JStzas15k+E-XHPNingkUOhagXYIXYYyacTsKMoHEf";
	private static final String OTP_SENDER_NAME="txtlcl";
	 public void init() {
	    	
	    	try {
	    	
	    		Class.forName("oracle.jdbc.driver.OracleDriver");
	    		conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","system","Sarfaraz123");
	    		if(conn!=null) {
	    			ps=conn.prepareStatement(RECOVER_PASS_QUERY);
	    			
	    		}else {	
	    			System.out.println("connection failed");
	    		}
	    	}catch(ClassNotFoundException cnfe) {
	    		
	    		cnfe.printStackTrace();
	    	}catch(SQLException sqle) {
	    		sqle.printStackTrace();
	    		
	    	}
	    	
	    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email= request.getParameter("email");
		String phone= request.getParameter("phone");
		String password= request.getParameter("password");
		String re_password= request.getParameter("re-password");
		try {
			ps.setString(1, email);
			ps.setString(2, phone);
			rs=ps.executeQuery();
			boolean login_matched_failed = false;
			login_matched_failed=rs.next();
			if(login_matched_failed==true) {
				
				String db_email=rs.getString(1);
				String db_username=rs.getString(2);
				String db_phone= rs.getString(3);
				
				int randomPin   =(int)(Math.random()*9000)+1000;
				String otp  =String.valueOf(randomPin);
				System.out.println("app_otp_recover_passServlet:"+otp);
//				try {
//					   String apiKey = "apikey=" +OTP_APIKEY;
//					   String message = "&message=" +otp;
//					   String sender = "&sender=" +OTP_SENDER_NAME;
//					   String numbers = "&numbers=" +db_phone;
//					   HttpURLConnection conn = (HttpURLConnection) new URL("https://api.textlocal.in/send/?").openConnection();
//					   String data = apiKey + numbers + message + sender;
//					   conn.setDoOutput(true);
//					   conn.setRequestMethod("POST");
//					   conn.setRequestProperty("Content-Length", Integer.toString(data.length()));
//					   conn.getOutputStream().write(data.getBytes("UTF-8"));
//					   final BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//					   final StringBuffer stringBuffer = new StringBuffer();
//					   String line;
//						   while ((line = rd.readLine()) != null) {
//						    
//						       JOptionPane.showMessageDialog(null,"message"+line);
//						   }
//						   rd.close();
//					  } catch (Exception e) {
//					      JOptionPane.showMessageDialog(null,e);
//					  }
				 db_username="Welcome "+db_username;
				 HttpSession session = request.getSession();
				 session.setAttribute("username",db_username);
				 session.setAttribute("otp",otp);
				 session.setAttribute("db_email",db_email);
				 session.setAttribute("db_phone",db_phone);
				 session.setAttribute("password",password);
				 session.setAttribute("re_password",re_password);
				 
				 RequestDispatcher rd=request.getRequestDispatcher("/OTP_Verification.jsp");
				 rd.forward(request,response);
			}else {
				String pass_recover_error_msg = "Sorry Email or Phone InCorrect!";  
		        request.setAttribute("pass_recover_error_msg",pass_recover_error_msg); 
				 RequestDispatcher rd=request.getRequestDispatcher("/Recover_Password_Page.jsp");
				 rd.forward(request,response);
			}
		}catch(SQLException sqle) {
			sqle.printStackTrace();
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
