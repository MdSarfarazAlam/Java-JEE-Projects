package com.sarfu.SignupLogin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/OTP_Verification_Servlet")
public class OTP_Verification_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    Connection conn=null;
    PrintWriter pw=null;
    PreparedStatement ps=null;
    private String username=null;
    private String db_email=null;
    private String db_phone=null;
    
	private static final String PASSWORD_UPDATE_QUERY="UPDATE SIGNUP_TABLE SET password=? WHERE email=? AND phone=?";
	public void init() {
		try {
	    	
    		Class.forName("oracle.jdbc.driver.OracleDriver");
    		conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","system","Sarfaraz123");
    		
    		if(conn!=null) {
    			System.out.println("connection : "+conn);
    			ps=conn.prepareStatement(PASSWORD_UPDATE_QUERY);
    			System.out.println("prepareStatement : "+ps);
    		}else {	
    			System.out.println("connection failed");
    		}
    	}catch(ClassNotFoundException cnfe) {
    		cnfe.printStackTrace();
    	}catch(SQLException sqle) {
    		sqle.printStackTrace();
    		
    	}
	}
	public void send_mail() {
		  String to = db_email;//change accordingly
	      String from = "sarfarazemails@gmail.com";//change accordingly
	      
	      System.out.println(db_email);
	     //Get the session object
	      System.out.println(username);
	      Properties properties = new Properties();
	      properties.put("mail.smtp.auth","true");
	      properties.put("mail.smtp.starttls.enable","true");
	      properties.put("mail.smtp.host","smtp.gmail.com");
	      properties.put("mail.smtp.port","587");
	      
	      
	      Session session = Session.getDefaultInstance(properties,new javax.mail.Authenticator() {
	    	  protected PasswordAuthentication getPasswordAuthentication() {
	    		  return new PasswordAuthentication("sarfarazemails@gmail.com","implode();123");
	    	  }
	      });

	     //compose the message
	      try{
	    	  
	         MimeMessage message = new MimeMessage(session);
	         message.setFrom(new InternetAddress(from));
	         message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
	         message.setSubject("Password reset successfull for SignUp/LogIn Application");
	         message.setText("Hello, "+username+" your password has been reset.Thank you for using My SignUp/LogIn Application...Enjoy!!!");
	         // Send message
	         Transport.send(message);
			 System.out.println("Mail send to destination mail");
			} catch (MessagingException e) {
			    // Error.
				 System.out.println("Mail not send to destination mail"+e);
			}
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String otp_value_form = request.getParameter("otp");
		
		 HttpSession session = request.getSession();
		
		 String otp_value_application = (String)session.getAttribute("app_otp");
		 
		
		System.out.println("Form otp value :"+otp_value_form);
		System.out.println("Application otp value : "+otp_value_application);
		
		if(otp_value_form.equals(otp_value_application)) {
			
			System.out.println("otp value equal true block: ");
			
			 username = (String)session.getAttribute("username");
			 db_email = (String)session.getAttribute("db_email");
			 db_phone = (String)session.getAttribute("db_phone");
			String password = (String)session.getAttribute("password");
			String re_password = (String)session.getAttribute("re_password");
			
			System.out.println("username :"+username);
			System.out.println("db_email :"+db_email);
			System.out.println("db_phone :"+db_phone);
			System.out.println("pass :"+password);
			System.out.println("re-pass :"+re_password);
			
			try {
				
				if(ps!=null) {
					ps.setString(1,password);
					ps.setString(2,db_email);
					ps.setString(3,db_phone);
					System.out.println("before query execute :");
					int res =ps.executeUpdate();
					System.out.println("after query execute");
					System.out.println("res :"+res);
					if(res!=0) {
						send_mail();
						RequestDispatcher rd = request.getRequestDispatcher("/OTP_Verification_Success.jsp");
						 rd.forward(request,response);
					}else {
						String server_error_msg = "Sorry Some Server error!";  
				        request.setAttribute("server_error_msg",server_error_msg); 
						RequestDispatcher rd = request.getRequestDispatcher("/Recover_Password_Page.jsp");
						 rd.forward(request,response);
					}
				}else {
					System.out.println("Update Query execution failed"+ps);
				}
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
			
		}else {
			System.out.println("otp value not equal false block: ");
			String otp_error_msg = "Sorry OTP InCorrect!";  
	        request.setAttribute("otp_error_msg",otp_error_msg); 
			RequestDispatcher rd = request.getRequestDispatcher("/OTP_Verification.jsp");
			rd.forward(request,response);
		}
		System.out.println(otp_value_form);
		System.out.println(otp_value_application);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
